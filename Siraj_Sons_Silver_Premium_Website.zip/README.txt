SIRAJ SONS SILVER — WEBSITE
==============================

Files:
- index.html
- style.css
- script.js

Verified listing details used:
- Business: Siraj sons silver Centaurus mall
- Category: Jewellery store
- Phone: +92 319 9259259
- Address: 1st Floor, opposite EGO, F 8/4 F-8, Islamabad, Pakistan
- Google Maps coordinates: 33.7078058, 73.0501097
- Opening hours: taken from the Google Maps listing at the time the site was built.

Editing:
- Business copy/content: index.html
- Colors/layout/responsiveness: style.css
- WhatsApp number/service messages/animations: script.js
- Replace gallery image URLs in index.html with your own product/store photos.
- The current gallery uses remote Unsplash images as representative placeholders.

Important:
- Google Fonts, Unsplash imagery and the embedded Google Map require an internet connection.
